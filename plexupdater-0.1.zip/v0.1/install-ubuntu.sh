#!/bin/bash

apt-get install -y npm
npm install -g forever
npm install node-tvdb node-bencode rimraf mv
apt-get install -y aria2c
